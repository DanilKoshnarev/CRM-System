package com.example.crm.domain.entities;

public class Contact {
    private String id;
    private String name;
    private String email;
    private String phoneNumber;

    public Contact(String id, String name, String email, String phoneNumber) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    // Getters and Setters
}