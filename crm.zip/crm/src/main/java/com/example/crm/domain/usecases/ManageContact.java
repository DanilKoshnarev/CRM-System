package com.example.crm.domain.usecases;

import com.example.crm.domain.entities.Contact;
import com.example.crm.domain.services.ContactService;

import java.util.List;

public class ManageContact {
    private final ContactService contactService;

    public ManageContact(ContactService contactService) {
        this.contactService = contactService;
    }

    public void createContact(String id, String name, String email, String phoneNumber) {
        Contact contact = new Contact(id, name, email, phoneNumber);
        contactService.addContact(contact);
    }

    public Contact viewContact(String id) {
        return contactService.getContact(id);
    }

    public List<Contact> viewAllContacts() {
        return contactService.getAllContacts();
    }

    public void removeContact(String id) {
        contactService.deleteContact(id);
    }
}