package com.example.crm.infrastructure.controllers;

import com.example.crm.domain.usecases.ManageContact;
import com.example.crm.domain.entities.Contact;

import java.util.List;

public class ContactController {
    private final ManageContact manageContact;

    public ContactController(ManageContact manageContact) {
        this.manageContact = manageContact;
    }

    public void addContact(String id, String name, String email, String phoneNumber) {
        manageContact.createContact(id, name, email, phoneNumber);
    }

    public Contact getContact(String id) {
        return manageContact.viewContact(id);
    }

    public List<Contact> getAllContacts() {
        return manageContact.viewAllContacts();
    }

    public void deleteContact(String id) {
        manageContact.removeContact(id);
    }
}