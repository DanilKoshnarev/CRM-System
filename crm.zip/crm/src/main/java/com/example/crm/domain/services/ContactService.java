package com.example.crm.domain.services;

import com.example.crm.domain.entities.Contact;
import com.example.crm.domain.repositories.ContactRepository;

import java.util.List;

public class ContactService {
    private final ContactRepository contactRepository;

    public ContactService(ContactRepository contactRepository) {
        this.contactRepository = contactRepository;
    }

    public void addContact(Contact contact) {
        contactRepository.save(contact);
    }

    public Contact getContact(String id) {
        return contactRepository.findById(id);
    }

    public List<Contact> getAllContacts() {
        return contactRepository.findAll();
    }

    public void deleteContact(String id) {
        contactRepository.delete(id);
    }
}