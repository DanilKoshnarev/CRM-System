package com.example.crm.domain.entities;

import java.util.Date;

public class Interaction {
    private String id;
    private String contactId;
    private String type;
    private Date date;
    private String notes;

    public Interaction(String id, String contactId, String type, Date date, String notes) {
        this.id = id;
        this.contactId = contactId;
        this.type = type;
        this.date = date;
        this.notes = notes;
    }

    // Getters and Setters
}