package com.example.crm.infrastructure.models;

import com.example.crm.domain.entities.Contact;
import com.example.crm.domain.repositories.ContactRepository;

import java.util.ArrayList;
import java.util.List;

public class ContactModel implements ContactRepository {
    private final List<Contact> contacts = new ArrayList<>();

    @Override
    public void save(Contact contact) {
        contacts.add(contact);
    }

    @Override
    public Contact findById(String id) {
        return contacts.stream().filter(contact -> contact.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public List<Contact> findAll() {
        return new ArrayList<>(contacts);
    }

    @Override
    public void delete(String id) {
        contacts.removeIf(contact -> contact.getId().equals(id));
    }
}