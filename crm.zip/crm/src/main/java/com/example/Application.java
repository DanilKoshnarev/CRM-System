package com.example.crm;

import com.example.crm.domain.entities.Contact;
import com.example.crm.domain.repositories.ContactRepository;
import com.example.crm.domain.services.ContactService;
import com.example.crm.domain.usecases.ManageContact;
import com.example.crm.infrastructure.models.ContactModel;
import com.example.crm.infrastructure.controllers.ContactController;

public class Application {
    public static void main(String[] args) {
        ContactRepository contactRepository = new ContactModel();
        ContactService contactService = new ContactService(contactRepository);
        ManageContact manageContact = new ManageContact(contactService);
        ContactController contactController = new ContactController(manageContact);

        // Add contacts
        contactController.addContact("1", "Alice", "alice@example.com", "123-456-7890");
        contactController.addContact("2", "Bob", "bob@example.com", "098-765-4321");

        // View all contacts
        for (Contact contact : contactController.getAllContacts()) {
            System.out.println("ID: " + contact.getId() + ", Name: " + contact.getName() + ", Email: " + contact.getEmail() + ", Phone: " + contact.getPhoneNumber());
        }

        // Delete contact
        contactController.deleteContact("1");

        // View all contacts after deletion
        for (Contact contact : contactController.getAllContacts()) {
            System.out.println("ID: " + contact.getId() + ", Name: " + contact.getName() + ", Email: " + contact.getEmail() + ", Phone: " + contact.getPhoneNumber());
        }
    }
}