package com.example.crm.domain.repositories;

import com.example.crm.domain.entities.Contact;

import java.util.List;

public interface ContactRepository {
    void save(Contact contact);
    Contact findById(String id);
    List<Contact> findAll();
    void delete(String id);
}